user_pref("autoadmin.global_config_url", "file:///opt/homebrew/opt/phoenix-osx/configs/twitter.cfg");
